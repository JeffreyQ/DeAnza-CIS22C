Hello Professor,

This program compiles and works fine on both Visual Studio 2015 and g++.

You can run it on a UNIX machine that has g++ with the following script (assuming you're
in the directory containing all of the source code):

	$ g++ main.cpp DisjointSets.cpp DisjointSets.h Graph.cpp Graph.h Room.cpp Room.h                                                                                                                                             Graph.h Room.cpp Room.h
	$ a.out
	$ a.out maze.txt

I've compiled it on multiple systems without error. 


Update: I resubmitted the project with more comments.

	

Regards,
Jeffrey Qiu